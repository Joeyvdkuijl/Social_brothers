<div class="blogs-container">
    <div class="blogs-container-in">
        <img src="<?php the_post_thumbnail_url() ?>" alt="Avatar" class="img-blog">
        <div class="special-text-img"><?php echo get_post_meta($post->ID, 'City', true) ?></div>
    </div>
    <div class="blogs-container-text">
        <div class="date">
            <?php echo get_the_date('Y-m-d') ?>
        </div>
        <div class="head-title-spec">
            <?php echo get_post_meta($post->ID, 'Title', true) ?>
        </div>
        <div class="head-text">
            <?php the_excerpt(); ?>
        </div>
        <div class="button-read-more">
            <a class="read-more" href="http://localhost:10005/blog/het-belang-van-digitoegankelijk-development/">lees meer <i class="fa-solid fa-arrow-right-long"></i></a>
        </div>
    </div>
</div>