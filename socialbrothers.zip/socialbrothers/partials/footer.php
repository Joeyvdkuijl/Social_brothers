<?php defined('ABSPATH') || exit('Forbidden'); ?>

</main>

<footer>
  <div class="footer-container">
    <div class="footer-container-in wrapper wrapper-1">
      <div class="text-footer">
        Algemene voowaarden
      </div>
      <div class="text-footer">
        Privacy statement
      </div>
      <div class="text-footer">
        Toegankelijkheidsverklaring
      </div>
    </div>
  </div>
</footer>

<?php
  wp_footer();
?>