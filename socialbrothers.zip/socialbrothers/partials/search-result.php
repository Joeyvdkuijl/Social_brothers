<div class="blogs-container">
    <div class="blogs-container-in">
        <img src="<?php the_post_thumbnail_url() ?>" alt="Avatar" class="img-blog">
        <?php
        echo '<div class="special-text-img">' . get_the_category($id)[0]->name . '</div>';
        ?>
    </div>
    <div class="blogs-container-text">
        <div class="head-title">
            <?php
            the_title();
            ?>
        </div>
        <div class="head-text">
            <?php the_excerpt(); ?>
        </div>
        <div class="button-read-more">
            <a class="read-more" href="http://localhost:10005/blog/het-belang-van-digitoegankelijk-development/">lees meer <i class="fa-solid fa-arrow-right-long"></i></a>
        </div>
    </div>
</div>