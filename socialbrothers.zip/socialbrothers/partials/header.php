<?php defined('ABSPATH') || exit('Forbidden'); ?>
<div class="popup">
  <div class="popup-content">
    <div class="close-float">
      <a class="close" id="close" onclick="closePopUp()"><i class="fa-solid fa-xmark"></i></a>
    </div>
    <div class="text-pop-up">
      <p class="text1Pop">Waar ben je naar opzoek?</p>
      <p class="text2Pop">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent luctus velit id ex vestibulum, in tristique risus tincidunt. </p>
      <?php
      get_search_form();
      ?>
    </div>
  </div>
</div>
<div class="container-header wrapper wrapper-1">
  <div class="left-side">
    <a href="http://localhost:10005/"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/SBlogo.png"></a>
  </div>
  <div class="right-side" id="myTopnav">
    <a href="javascript:void(0);" class="icon" onclick="myFunction()">
      <i class="fa fa-bars"></i>
    </a>
    <div class="container-btn">
    <div class="icon blog-button mobile">
        <a href="http://localhost:10005/">Home</a>
      </div>
      <div class="blog-button mobile">
        <a href="http://localhost:10005/blog/">Blog</a>
      </div>
      <div class="events-button mobile">
        <a href="#targetdiv">Events</a>
      </div>
      <div class="search-button mobile">
        <a id="press"><i class="fa-solid fa-magnifying-glass"></i></a>
      </div>
      <div class="login mobile">
        <a href="http://localhost:10005/login/?preview_id=143&preview_nonce=2edc36d78f&_thumbnail_id=-1&preview=true" class="button">Log in</a>
      </div>
    </div>
  </div>
</div>