<div class="blogs-container-single">
    <div class="blogs-container-text">

        <?php
        echo '<div class="tag">' . get_the_category($id)[0]->name . '</div>';
        ?>

        <div class="header-text">
            <?php

            the_title();

            ?>
        </div>

        <div class="body-text">
            <?php
            the_content();
            ?>
        </div>

    </div>
</div>
<div class="events">
        <div class="header-text reletated-blog" action="#targetdiv">
            Gerelateerde blogs
        </div>
        <div class="home-container">
            <div class="home-container-in">
                <div class="blogs">
                    <?php

                    // $value = $_GET['city-button'];

                    $args = array(
                        'post_type' => 'Blogs',
                        'post_status' => 'publish',
                        'posts_per_page' => 3,
                        'meta_key' => 'relate-blog',
                        'meta_value' => 'blog'
                    );

                    $loop = new WP_Query($args);

                    if ($loop->have_posts()) :
                        while ($loop->have_posts()) : $loop->the_post();

                            get_template_part('partials/blog', 'relate');

                        endwhile;
                    endif;

                    ?>
                </div>
            </div>
        </div>
    </div>