<?php defined('ABSPATH') || exit('Forbidden');
get_header();

/* Template Name: Blog-single */

?>
<div class="container-header-body-blog">
    <div class="container-img-single">
        <?php

        while (have_posts()) {

            the_post();

        ?>
            <img class="img-header" src="<?php the_post_thumbnail_url() ?>">
        <?php
        }
        ?>
    </div>
</div>
<div class="home-container">
    <div class="wrapper wrapper-1">
        <div class="home-container-in">
            <div class="blogs">
                <?php

                while (have_posts()) {

                    the_post();

                    get_template_part('partials/blog', 'single');

                ?>



                <?php
                }
                ?>
            </div>
        </div>
    </div>
</div>
</div>


<?php
get_footer();
?>