<?php defined('ABSPATH') || exit('Forbidden');

/* Template Name: login */

get_header();

?>

<div class="login-container">
    <div class="login-container-in">
        <div class="text-pop-up-spec">
            <div class="text-pop-up-in">
                <p class="text1Pop">Login bij Social Brothers</p>
                <p class="text2Pop">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Magnis dis parturient montes nascetur ridiculus mus mauris vitae ultricies. </p>
                <form role="search" method="get" id="searchform" class="searchform" action="' . home_url('/') . '">
                    <div class="custom-login">
                        <label class="screen-reader-text" for="s"></label>
                        <div class="login-val">
                            <div class="login-val-user">
                                <input style="border: 0!important;" type="text" value="" name="s" id="s" placeholder=" Gebruikersnaam..." />
                            </div>
                            <div class="login-val-password">
                                <input style="border: 0!important;" type="text" value="" name="s" id="s" placeholder=" Wachtwoord..." />
                            </div>
                        </div>
                        <input class="button-login" type="login" id="searchsubmit" value="Log in" />
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

</body>

</html>