<?php defined('ABSPATH') || exit('Forbidden');

get_header();

?>
<div class="container-header-body-blog">
    <div class="container-img-blog">
        <img class="img-header" src="<?php the_post_thumbnail_url() ?>">
        <div class="overlay">
            <div class="block-overlay">
                <div class="overlay-header">Blogs</div>
            </div>
        </div>
    </div>
</div>
<div class="home-page">
    <div class="home-container">
        <div class="wrapper wrapper-1">
            <div class="home-container-in">
                <div class="blogs">


                    <?php

                    $args = array(
                        'post_type' => 'blogs',
                        'post_status' => 'publish',
                        'posts_per_page' => 9
                    );

                    $loop = new WP_Query($args);

                    if ($loop->have_posts()) :
                        while ($loop->have_posts()) : $loop->the_post();

                            get_template_part('partials/blog', 'archive');

                        endwhile;
                    endif;

                    ?>
                </div>
                <?php if (have_posts()) : ?>

                    <!-- Start the pagination functions before the loop. -->

                    <!-- End the pagination functions before the loop. -->

                    <!-- Start of the main loop. -->
                    <?php while (have_posts()) : the_post();  ?>

                        <!-- the rest of your theme's main loop -->

                    <?php endwhile; ?>
                    <!-- End of the main loop -->

                    <!-- Start the pagination functions after the loop. -->
                    <div class="nav-previous"><?php next_posts_link('next'); ?></div>
                    <div class="nav-next"><?php previous_posts_link('previous'); ?></div>
                    <!-- End the pagination functions after the loop. -->

                <?php else : ?>

                    <?php _e('Sorry, no posts matched your criteria.'); ?>

                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php
get_footer();
?>