<?php get_header();
?>
<div class="container-img-search">
    <img class="img-header" src="<?php echo get_template_directory_uri(); ?>/assets/images/2cbdc7b29b8b729db1b0ad933d96d3cbc1f83268.jpg">
    <div class="overlay">
        <div class="block-overlay">
            <div class="overlay-header">Zoekresultaten</div>
        </div>
    </div>
</div>
<div class="home-container-in wrapper wrapper-1">
    <div class="custom-search-page-search">
    <?php
    get_search_form();
    ?>
    </div>
    <div class="header-text" style="padding: 40px 0px 80px 0px;">
        Alle zoekresultaten voor "<?php echo the_search_query(); ?>"
    </div>
    <div>
        <div class="search-page">
            <div class="search-container">
                <div class="search-container-in">
                    <div class="counter">
                        <?php
                        $allsearch = new WP_Query("s=$s&showposts=0");
                        echo $allsearch->found_posts . ' resultaten gevonden';
                        ?>
                    </div>
                    <div class="search-results">
                        <?php
                        if (have_posts()) {
                            while (have_posts()) {
                                the_post();

                                // the_content();

                                get_template_part('partials/search', 'result');
                            }
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>

<?php get_footer();
?>