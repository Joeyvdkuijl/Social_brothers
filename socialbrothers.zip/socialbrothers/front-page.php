<?php defined('ABSPATH') || exit('Forbidden');

/* Template Name: Blogs */

get_header();

$city_button = isset($_GET['city-button']) ? $_GET['city-button'] : 'Leiden';

?>

<div class="container-img">
    <img class="img-header" src="<?php echo get_template_directory_uri(); ?>/assets/images/2cbdc7b29b8b729db1b0ad933d96d3cbc1f83268.jpg">
    <div class="overlay">
        <div class="block-overlay">
            <div class="overlay-header"><?php echo get_post_meta($post->ID, 'Title', true) ?></div>
            <div class="overlay-text">Deze opdracht dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Magnis dis parturient montes nascetur ridiculus mus mauris vitae ultricies. Commodo odio aenean sed adipiscing diam donec adipiscing tristique risus. </div>
        </div>
    </div>
</div>
</div>
<div class="home-page">
    <div class="home-container">
        <div class="wrapper wrapper-1">
            <div class="home-container-in">
                <div class="header-text" style="padding-top: 80px;">
                    De nieuwste blogs
                </div>
                <div class="blogs">
                    <div class="home-page">
                        <div class="home-container">
                            <div class="home-container-in">
                                <div class="blogs">
                                    <?php

                                    $args = array(
                                        'post_type' => 'blogs',
                                        'post_status' => 'publish',
                                        'posts_per_page' => 3
                                    );

                                    $loop = new WP_Query($args);

                                    if ($loop->have_posts()) :
                                        while ($loop->have_posts()) : $loop->the_post();

                                            get_template_part('partials/blog', 'archive');

                                        endwhile;
                                    endif;

                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="events">
                <div class="header-text" action="#targetdiv">
                    Opkomende events
                </div>
                <div class="event-buttons">
                    <div class="btn-container">
                        <?php

                        $buttons = ['Leiden', 'Utrecht', 'Rotterdam'];

                        for ($i = 0; $i < count($buttons); $i++) {
                            $active = $city_button === $buttons[$i] ? 'orange' : '';
                            echo "<a href='/?city-button={$buttons[$i]}'><input class='button-spec {$active}' name='city-button' type='submit' id='city-button-1' value='Events {$buttons[$i]}' /></a>";
                        }

                        ?>
                    </div>
                </div>
                <div class="home-container">
                    <div class="home-container-in">
                        <div class="blogs">
                            <?php

                            $args = array(
                                'post_type' => 'Blogs',
                                'post_status' => 'publish',
                                'posts_per_page' => 3,
                                'meta_key' => 'City',
                                'meta_value' => $city_button
                            );
                            
                            $loop = new WP_Query($args);

                            if ($loop->have_posts()) :
                                while ($loop->have_posts()) : $loop->the_post();

                                    get_template_part('partials/event', 'archive');

                                endwhile;
                            endif;

                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
get_footer();
?>