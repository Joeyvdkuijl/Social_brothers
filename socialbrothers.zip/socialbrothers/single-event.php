<?php defined('ABSPATH') || exit('Forbidden');
get_header();

/* Template Name: event-single */

?>
<div class="container-header-body-blog">
    <div class="container-img-single">
        <img class="img-header" src="<?php echo get_template_directory_uri(); ?>/assets/images/719d7119b323a629a782fa92dd43e21e888590ab.jpg">
    </div>
</div>
<div class="home-container">
    <div class="wrapper wrapper-1">
        <div class="home-container-in">
            <div class="blogs">
                <?php
                
                while (have_posts()) {

                    the_post();

                    get_template_part('partials/event', 'single');

                ?>



                <?php
                }
                ?>
            </div>
        </div>
    </div>
</div>
</div>


<?php
get_footer();
?>