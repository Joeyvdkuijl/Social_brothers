<?php defined('ABSPATH') || exit('Forbidden');

// Require theme files
require_once get_template_directory() . "/lib/init.php";

/**
 * Disable Gutenberg block editor
 * 
 * @see https://developer.wordpress.org/reference/hooks/use_block_editor_for_post/
 */
add_filter('use_block_editor_for_post', '__return_false', 10, 0);


function socialborthers_theme_support()
{

    add_theme_support('title-tag');
    add_theme_support('custom-logo');
}

add_action('after_setup_theme', 'socialborthers_theme_support');

/* Custom Post Type Start */
function create_posttype_blog()
{
    register_post_type(
        'blogs',
        // CPT Options
        array(
            'labels' => array(
                'name' => __('blogs'),
                'singular_name' => __('blogs')
            ),
            'public' => true,
            'has_archive' => false,
            'rewrite' => array('slug' => 'blogs'),
        )
    );
}
// Hooking up our function to theme setup
add_action('init', 'create_posttype_blog');
/* Custom Post Type End */

/*Custom Post type start*/
function cw_post_type_blog()
{
    $supports = array(
        'title', // post title
        'editor', // post content
        'thumbnail', // featured images
        'excerpt', // post excerpt
        'custom-fields', // custom fields
        'comments', // post comments
        'revisions', // post revisions
        'post-formats', // post formats
    );
    $labels = array(
        'name' => _x('blogs', 'plural'),
        'singular_name' => _x('blogs', 'singular'),
        'menu_name' => _x('blogs', 'admin menu'),
        'name_admin_bar' => _x('blogs', 'admin bar'),
        'add_new' => _x('Add New', 'add new'),
        'add_new_item' => __('Add New blogs'),
        'new_item' => __('New blogs'),
        'edit_item' => __('Edit blogs'),
        'view_item' => __('View blogs'),
        'all_items' => __('All blogs'),
        'search_items' => __('Search blogs'),
        'not_found' => __('No blogs found.'),
    );
    $args = array(
        'supports' => $supports,
        'labels' => $labels,
        'public' => true,
        'query_var' => true,
        'rewrite' => array('slug' => 'blogs'),
        'has_archive' => true,
        'hierarchical' => false,
    );
    register_post_type('blogs', $args);
}
add_action('init', 'cw_post_type_blog');
/*Custom Post type end*/



function socialbrothers_register_script()
{

    wp_enqueue_script('socialborthers-script', get_template_directory_uri() . "/src/scripts/main.js", array(), "1.1", true);
}

add_action("wp_enqueue_scripts", "socialbrothers_register_script");

function custom_search_form($form)
{
    $form = '<form role="search" method="get" id="searchform" class="searchform" action="' . home_url('/') . '" >
      <div class="custom-form"><label class="screen-reader-text" for="s">' . __('Zoeken:') . '</label>
      <div class="search-bar">
      <input style="border: 0!important;" type="text" value="' . get_search_query() . '" name="s" id="s" placeholder=" Ik ben opzoek naar..." />
      </div>
    <input class="button" type="submit" id="searchsubmit" value="' . esc_attr__('Zoeken') . '" />
    </div>
    </form>';

    return $form;
}
add_filter('get_search_form', 'custom_search_form', 40);
