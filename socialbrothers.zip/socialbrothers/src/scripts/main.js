//open
document.getElementById("press").addEventListener("click", function () {
    document.querySelector(".popup").style.display = "flex";
});

//close
function closePopUp() {
    document.getElementById("close").addEventListener("click", function () {
        document.querySelector(".popup").style.display = "none";
    });
};

document.getElementById("city-button-1").addEventListener("click", function () {
    let button_2 = document.getElementById("city-button-2");
    let button_1 = document.getElementById("city-button-1");
    let button_3 = document.getElementById("city-button-3");
    if (button_2.classList.contains('orange') || button_3.classList.contains('orange')) {
        button_1.classList.add('orange');
        button_2.classList.remove('orange');
        button_3.classList.remove('orange');
    } else {
        button_1.classList.add('orange');
    }
});

document.getElementById("city-button-2").addEventListener("click", function () {
    let button_2 = document.getElementById("city-button-2");
    let button_1 = document.getElementById("city-button-1");
    let button_3 = document.getElementById("city-button-3");
    if (button_1.classList.contains('orange') || button_3.classList.contains('orange')) {
        button_1.classList.remove('orange');
        button_2.classList.add('orange');
        button_3.classList.remove('orange');
    } else {
        button_2.classList.add('orange');
    }
});

document.getElementById("city-button-3").addEventListener("click", function () {
    let button_2 = document.getElementById("city-button-2");
    let button_1 = document.getElementById("city-button-1");
    let button_3 = document.getElementById("city-button-3");
    if (button_1.classList.contains('orange') || button_2.classList.contains('orange')) {
        button_1.classList.remove('orange');
        button_2.classList.remove('orange');
        button_3.classList.add('orange');
    } else {
        button_3.classList.add('orange');
    }
});

function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "right-side") {
      x.className += " responsive";
    } else {
      x.className = "right-side";
    }
  }