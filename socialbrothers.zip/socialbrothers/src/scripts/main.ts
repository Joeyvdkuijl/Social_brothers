import '@fortawesome/fontawesome-free/js/solid.js';
import '@fortawesome/fontawesome-free/js/fontawesome.js';

document.addEventListener('DOMContentLoaded', () => {
  console.log('DOM Loaded');
});

// var count = 1;
// function setColor(btn, color) {
//     var property = document.getElementById(btn);
//     if (count == 0) {
//         property.style.backgroundColor = "#FFFFFF"
//         count = 1;        
//     }
//     else {
//         property.style.backgroundColor = "#7FFF00"
//         count = 0;
//     }
// }

//open
// document.getElementById("pers").addEventListener("click", function(){
//   document.querySelector(".popup").style.display = "flex";
// });
// document.getElementById("persMobile").addEventListener("click", function(){
//   document.querySelector(".popup").style.display = "flex";
// });

// //close
// document.querySelector(".popBut").addEventListener("click", function(){
//   document.querySelector(".popup").style.display = "none";
// });
// document.querySelector(".close").addEventListener("click", function(){
//   document.querySelector(".popup").style.display = "none";
// });
