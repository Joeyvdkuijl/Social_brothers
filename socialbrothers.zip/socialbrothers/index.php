<?php 

get_header();

?>
 
<?php
           get_template_part('partials/blog', 'single');
?>
<?php
           get_template_part('partials/event', 'single');
?>

<?php 

get_footer();

?> 